AI-SOC sample flow logs

Upload one CSV at a time on the Analyze page. Start with demo_ddos_T1498.csv: it produces one incident. The brute-force sample produces two incidents and the botnet sample produces eight, so those can use more Gemini API quota when automatic investigation is enabled.

These are CICIDS2017/CICFlowMeter flow records, not host syslogs. Ground-truth Label values are used only as explicit annotation signals; they are not independent detection.
